Noltri 3.0 third-party notices.
Reviewed production dependency superset for desktop, Core, MCP and the locked macOS arm64 runtime. This material does not grant a license to Noltri-owned code.
Original upstream license and NOTICE texts are retained; INDEX.json records dependency versions and selected license expressions. CORRESPONDING-SOURCE.txt supplies exact upstream source references. Node LICENSE is additionally shipped as node-LICENSE.txt.
